import { useState } from 'react';
import { 
  BookOpen, 
  Heart, 
  Sparkles, 
  ChevronRight, 
  Quote, 
  Menu, 
  X,
  Play,
  Pause,
  Bookmark,
  Search,
  Sun,
  Flame,
  Eye,
  Star
} from 'lucide-react';
import { chapters, getDailyVerse, type Chapter } from './data/chapters';
import './App.css';

function App() {
  const [selectedChapter, setSelectedChapter] = useState<Chapter | null>(null);
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [bookmarkedVerses, setBookmarkedVerses] = useState<number[]>([]);
  const [isPlaying, setIsPlaying] = useState(false);
  const verseOfDay = getDailyVerse();

  // Scroll to section
  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
      setIsMenuOpen(false);
    }
  };

  // Toggle bookmark
  const toggleBookmark = (verseId: number) => {
    setBookmarkedVerses(prev => 
      prev.includes(verseId) 
        ? prev.filter(id => id !== verseId)
        : [...prev, verseId]
    );
  };

  // Filter chapters based on search
  const filteredChapters = chapters.filter(chapter => 
    chapter.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    chapter.sanskritName.includes(searchQuery) ||
    chapter.summary.toLowerCase().includes(searchQuery.toLowerCase())
  );

  // Text to speech for verses
  const speakVerse = (text: string) => {
    if ('speechSynthesis' in window) {
      if (isPlaying) {
        window.speechSynthesis.cancel();
        setIsPlaying(false);
      } else {
        const utterance = new SpeechSynthesisUtterance(text);
        utterance.rate = 0.8;
        utterance.pitch = 1;
        utterance.onend = () => setIsPlaying(false);
        window.speechSynthesis.speak(utterance);
        setIsPlaying(true);
      }
    }
  };

  return (
    <div className="min-h-screen bg-[#0F0F1A] text-[#F5F5F0] overflow-x-hidden">
      {/* Navigation */}
      <nav className="fixed top-0 left-0 right-0 z-50 glass border-b border-[#D4AF37]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center gap-2">
              <Sparkles className="w-6 h-6 text-[#D4AF37]" />
              <span className="text-xl font-bold text-[#D4AF37]" style={{ fontFamily: 'Cinzel Decorative, serif' }}>
                Gita Wisdom
              </span>
            </div>
            
            {/* Desktop Navigation */}
            <div className="hidden md:flex items-center gap-8">
              {['Home', 'About', 'Chapters', 'Teachings', 'Verse of the Day'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase().replace(/\s+/g, '-'))}
                  className="text-sm text-[#F5F5F0]/80 hover:text-[#D4AF37] transition-colors duration-300 ui-text"
                >
                  {item}
                </button>
              ))}
            </div>

            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-2"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Menu */}
        {isMenuOpen && (
          <div className="md:hidden glass border-t border-[#D4AF37]/20">
            <div className="px-4 py-4 space-y-3">
              {['Home', 'About', 'Chapters', 'Teachings', 'Verse of the Day'].map((item) => (
                <button
                  key={item}
                  onClick={() => scrollToSection(item.toLowerCase().replace(/\s+/g, '-'))}
                  className="block w-full text-left text-[#F5F5F0]/80 hover:text-[#D4AF37] transition-colors py-2 ui-text"
                >
                  {item}
                </button>
              ))}
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section id="home" className="relative min-h-screen flex items-center justify-center overflow-hidden">
        {/* Background Image */}
        <div className="absolute inset-0">
          <img 
            src="/hero-bg.jpg" 
            alt="Cosmic Background" 
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-[#0F0F1A]/60 via-[#0F0F1A]/40 to-[#0F0F1A]" />
        </div>

        {/* Floating Particles Effect */}
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute w-1 h-1 bg-[#D4AF37] rounded-full animate-float"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 5}s`,
                opacity: Math.random() * 0.5 + 0.2
              }}
            />
          ))}
        </div>

        {/* Hero Content */}
        <div className="relative z-10 text-center px-4 max-w-5xl mx-auto">
          <div className="mb-6 animate-fade-in">
            <span className="text-[#D4AF37] text-lg tracking-[0.3em] uppercase ui-text">
              The Divine Song
            </span>
          </div>
          
          <h1 
            className="text-5xl sm:text-7xl md:text-8xl font-bold mb-6 text-shadow-glow animate-fade-in-up"
            style={{ fontFamily: 'Cinzel Decorative, serif' }}
          >
            <span className="text-[#D4AF37]">Bhagavad</span>
            <span className="text-[#F5F5F0]"> Gita</span>
          </h1>
          
          <p 
            className="text-xl sm:text-2xl text-[#F5F5F0]/80 mb-4 animate-fade-in"
            style={{ animationDelay: '0.3s' }}
          >
            The Song of the Divine
          </p>
          
          <p 
            className="text-base sm:text-lg text-[#F5F5F0]/60 max-w-2xl mx-auto mb-10 animate-fade-in"
            style={{ animationDelay: '0.5s' }}
          >
            Discover the timeless wisdom of the Gita, a guide to self-realization, 
            inner peace, and spiritual enlightenment.
          </p>

          <button
            onClick={() => scrollToSection('chapters')}
            className="group relative px-8 py-4 bg-gradient-to-r from-[#D4AF37] to-[#FF9933] text-[#0F0F1A] font-bold rounded-full overflow-hidden transition-all duration-300 hover:shadow-[0_0_30px_rgba(212,175,55,0.5)] animate-fade-in ui-text"
            style={{ animationDelay: '0.7s' }}
          >
            <span className="relative z-10 flex items-center gap-2">
              Begin Your Journey
              <ChevronRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </span>
          </button>
        </div>

        {/* Scroll Indicator */}
        <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
          <div className="w-6 h-10 border-2 border-[#D4AF37]/50 rounded-full flex justify-center pt-2">
            <div className="w-1 h-2 bg-[#D4AF37] rounded-full animate-pulse" />
          </div>
        </div>
      </section>

      {/* About Section */}
      <section id="about" className="py-20 sm:py-32 relative">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 lg:gap-20 items-center">
            {/* Image */}
            <div className="relative group">
              <div className="absolute -inset-4 bg-gradient-to-r from-[#D4AF37]/20 to-[#FF9933]/20 rounded-2xl blur-xl opacity-0 group-hover:opacity-100 transition-opacity duration-500" />
              <div className="relative overflow-hidden rounded-2xl border border-[#D4AF37]/30">
                <img 
                  src="/krishna-arjuna.jpg" 
                  alt="Krishna and Arjuna" 
                  className="w-full h-auto transform group-hover:scale-105 transition-transform duration-700"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F1A]/80 to-transparent" />
              </div>
            </div>

            {/* Content */}
            <div className="space-y-6">
              <div className="flex items-center gap-3">
                <BookOpen className="w-6 h-6 text-[#D4AF37]" />
                <span className="text-[#D4AF37] text-sm tracking-widest uppercase ui-text">About the Scripture</span>
              </div>
              
              <h2 
                className="text-4xl sm:text-5xl font-bold text-[#F5F5F0]"
                style={{ fontFamily: 'Cinzel Decorative, serif' }}
              >
                About the <span className="text-[#D4AF37]">Gita</span>
              </h2>

              <p className="text-lg text-[#F5F5F0]/80 leading-relaxed">
                The Bhagavad Gita, often referred to as the Gita, is a 700-verse Hindu scripture 
                that is part of the epic Mahabharata. It records the profound conversation between 
                Prince Arjuna and Lord Krishna on the battlefield of Kurukshetra.
              </p>

              <p className="text-lg text-[#F5F5F0]/70 leading-relaxed">
                Spoken over 5,000 years ago, the Gita's teachings transcend time and culture, 
                offering practical guidance for living a life of purpose, peace, and spiritual 
                fulfillment. It addresses the fundamental questions of existence and provides 
                a path to self-realization.
              </p>

              {/* Stats */}
              <div className="grid grid-cols-3 gap-6 pt-6">
                <div className="text-center p-4 glass rounded-xl border border-[#D4AF37]/20">
                  <div className="text-3xl font-bold text-[#D4AF37]">18</div>
                  <div className="text-sm text-[#F5F5F0]/60 ui-text">Chapters</div>
                </div>
                <div className="text-center p-4 glass rounded-xl border border-[#D4AF37]/20">
                  <div className="text-3xl font-bold text-[#D4AF37]">700</div>
                  <div className="text-sm text-[#F5F5F0]/60 ui-text">Verses</div>
                </div>
                <div className="text-center p-4 glass rounded-xl border border-[#D4AF37]/20">
                  <div className="text-3xl font-bold text-[#D4AF37]">∞</div>
                  <div className="text-sm text-[#F5F5F0]/60 ui-text">Wisdom</div>
                </div>
              </div>

              {/* Quote */}
              <div className="mt-8 p-6 glass rounded-xl border-l-4 border-[#D4AF37]">
                <Quote className="w-8 h-8 text-[#D4AF37]/50 mb-3" />
                <p className="text-lg text-[#F5F5F0]/90 italic">
                  "When meditation is mastered, the mind is unwavering like the flame of a lamp in a windless place."
                </p>
                <p className="text-sm text-[#D4AF37] mt-3 ui-text">— Bhagavad Gita 6.19</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Chapters Section */}
      <section id="chapters" className="py-20 sm:py-32 relative">
        <div className="absolute inset-0 bg-gradient-to-b from-[#0F0F1A] via-[#1A1A2E]/50 to-[#0F0F1A]" />
        
        <div className="relative z-10 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-12">
            <span className="text-[#D4AF37] text-sm tracking-widest uppercase ui-text">Spiritual Journey</span>
            <h2 
              className="text-4xl sm:text-5xl font-bold text-[#F5F5F0] mt-3"
              style={{ fontFamily: 'Cinzel Decorative, serif' }}
            >
              Explore the <span className="text-[#D4AF37]">Chapters</span>
            </h2>
            <p className="text-lg text-[#F5F5F0]/60 mt-4 max-w-2xl mx-auto">
              Dive into the 18 chapters of spiritual wisdom, each revealing profound truths about life, duty, and the self.
            </p>
          </div>

          {/* Search */}
          <div className="max-w-md mx-auto mb-12">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-[#D4AF37]/60" />
              <input
                type="text"
                placeholder="Search chapters..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="w-full pl-12 pr-4 py-3 glass rounded-full border border-[#D4AF37]/30 text-[#F5F5F0] placeholder-[#F5F5F0]/40 focus:outline-none focus:border-[#D4AF37] transition-colors ui-text"
              />
            </div>
          </div>

          {/* Chapter Grid */}
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredChapters.map((chapter, index) => (
              <div
                key={chapter.id}
                onClick={() => setSelectedChapter(chapter)}
                className="group relative glass rounded-2xl p-6 border border-[#D4AF37]/20 hover:border-[#D4AF37]/60 transition-all duration-300 cursor-pointer hover:-translate-y-2"
                style={{ animationDelay: `${index * 0.1}s` }}
              >
                {/* Chapter Number */}
                <div className="absolute -top-4 -right-4 w-12 h-12 bg-gradient-to-br from-[#D4AF37] to-[#FF9933] rounded-full flex items-center justify-center text-[#0F0F1A] font-bold text-lg">
                  {chapter.id}
                </div>

                <div className="mb-4">
                  <h3 
                    className="text-xl font-bold text-[#F5F5F0] group-hover:text-[#D4AF37] transition-colors"
                    style={{ fontFamily: 'Cinzel Decorative, serif' }}
                  >
                    {chapter.name}
                  </h3>
                  <p className="text-[#D4AF37]/80 text-sm mt-1">{chapter.sanskritName}</p>
                </div>

                <p className="text-[#F5F5F0]/60 text-sm line-clamp-3 mb-4">
                  {chapter.summary}
                </p>

                <div className="flex items-center justify-between">
                  <span className="text-xs text-[#F5F5F0]/40 ui-text">{chapter.verses} Verses</span>
                  <div className="flex items-center gap-2 text-[#D4AF37] text-sm ui-text group-hover:gap-3 transition-all">
                    Read <ChevronRight className="w-4 h-4" />
                  </div>
                </div>

                {/* Hover Glow */}
                <div className="absolute inset-0 rounded-2xl bg-gradient-to-r from-[#D4AF37]/0 via-[#D4AF37]/10 to-[#D4AF37]/0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 pointer-events-none" />
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Key Teachings Section */}
      <section id="teachings" className="py-20 sm:py-32 relative overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          {/* Header */}
          <div className="text-center mb-16">
            <span className="text-[#D4AF37] text-sm tracking-widest uppercase ui-text">Paths to Liberation</span>
            <h2 
              className="text-4xl sm:text-5xl font-bold text-[#F5F5F0] mt-3"
              style={{ fontFamily: 'Cinzel Decorative, serif' }}
            >
              The Three <span className="text-[#D4AF37]">Yogas</span>
            </h2>
            <p className="text-lg text-[#F5F5F0]/60 mt-4 max-w-2xl mx-auto">
              The Gita teaches three primary paths to spiritual realization—each suited to different temperaments and stages of life.
            </p>
          </div>

          {/* Yoga Cards */}
          <div className="grid md:grid-cols-3 gap-8">
            {/* Karma Yoga */}
            <div className="group relative overflow-hidden rounded-2xl">
              <div className="absolute inset-0">
                <img 
                  src="/karma-yoga.jpg" 
                  alt="Karma Yoga" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F1A] via-[#0F0F1A]/70 to-transparent" />
              </div>
              
              <div className="relative p-8 min-h-[500px] flex flex-col justify-end">
                <div className="mb-4">
                  <Flame className="w-10 h-10 text-[#FF9933]" />
                </div>
                <h3 
                  className="text-2xl font-bold text-[#F5F5F0] mb-2"
                  style={{ fontFamily: 'Cinzel Decorative, serif' }}
                >
                  Karma Yoga
                </h3>
                <p className="text-[#FF9933] text-sm mb-4 ui-text">Path of Action</p>
                <p className="text-[#F5F5F0]/70 mb-6">
                  Perform your duties selflessly, without attachment to the fruits of your actions. 
                  Action is necessary for life—do your work as an offering to the Divine.
                </p>
                <div className="p-4 glass rounded-lg border-l-2 border-[#FF9933]">
                  <p className="text-sm text-[#F5F5F0]/80 italic">
                    "You have the right to perform your duty, but not to the fruits thereof."
                  </p>
                </div>
              </div>
            </div>

            {/* Bhakti Yoga */}
            <div className="group relative overflow-hidden rounded-2xl">
              <div className="absolute inset-0">
                <img 
                  src="/bhakti-yoga.jpg" 
                  alt="Bhakti Yoga" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F1A] via-[#0F0F1A]/70 to-transparent" />
              </div>
              
              <div className="relative p-8 min-h-[500px] flex flex-col justify-end">
                <div className="mb-4">
                  <Heart className="w-10 h-10 text-[#D4AF37]" />
                </div>
                <h3 
                  className="text-2xl font-bold text-[#F5F5F0] mb-2"
                  style={{ fontFamily: 'Cinzel Decorative, serif' }}
                >
                  Bhakti Yoga
                </h3>
                <p className="text-[#D4AF37] text-sm mb-4 ui-text">Path of Devotion</p>
                <p className="text-[#F5F5F0]/70 mb-6">
                  The simplest and highest path—worship the Divine with pure love and devotion. 
                  Surrender your heart and find liberation through unconditional love.
                </p>
                <div className="p-4 glass rounded-lg border-l-2 border-[#D4AF37]">
                  <p className="text-sm text-[#F5F5F0]/80 italic">
                    "Whoever worships Me with love and faith, I reside in their heart."
                  </p>
                </div>
              </div>
            </div>

            {/* Jnana Yoga */}
            <div className="group relative overflow-hidden rounded-2xl">
              <div className="absolute inset-0">
                <img 
                  src="/jnana-yoga.jpg" 
                  alt="Jnana Yoga" 
                  className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F0F1A] via-[#0F0F1A]/70 to-transparent" />
              </div>
              
              <div className="relative p-8 min-h-[500px] flex flex-col justify-end">
                <div className="mb-4">
                  <Eye className="w-10 h-10 text-[#9C27B0]" />
                </div>
                <h3 
                  className="text-2xl font-bold text-[#F5F5F0] mb-2"
                  style={{ fontFamily: 'Cinzel Decorative, serif' }}
                >
                  Jnana Yoga
                </h3>
                <p className="text-[#9C27B0] text-sm mb-4 ui-text">Path of Knowledge</p>
                <p className="text-[#F5F5F0]/70 mb-6">
                  Discriminate between the eternal soul and the temporary body. 
                  Through wisdom and contemplation, realize your true nature as spirit.
                </p>
                <div className="p-4 glass rounded-lg border-l-2 border-[#9C27B0]">
                  <p className="text-sm text-[#F5F5F0]/80 italic">
                    "The soul is neither born nor does it ever die."
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Verse of the Day Section */}
      <section id="verse-of-the-day" className="py-20 sm:py-32 relative">
        <div className="absolute inset-0 bg-[#1A1A2E]" />
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[600px] h-[600px] border border-[#D4AF37] rounded-full" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[400px] h-[400px] border border-[#D4AF37]/50 rounded-full" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[200px] h-[200px] border border-[#D4AF37]/30 rounded-full" />
        </div>

        <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <div className="flex items-center justify-center gap-3 mb-8">
            <Sun className="w-6 h-6 text-[#D4AF37]" />
            <span className="text-[#D4AF37] text-sm tracking-widest uppercase ui-text">Daily Inspiration</span>
          </div>

          <h2 
            className="text-4xl sm:text-5xl font-bold text-[#F5F5F0] mb-12"
            style={{ fontFamily: 'Cinzel Decorative, serif' }}
          >
            Verse of the <span className="text-[#D4AF37]">Day</span>
          </h2>

          <div className="glass rounded-3xl p-8 sm:p-12 border border-[#D4AF37]/30">
            <Quote className="w-12 h-12 text-[#D4AF37]/30 mx-auto mb-6" />
            
            <p className="text-2xl sm:text-3xl text-[#F5F5F0] leading-relaxed mb-6 animate-pulse-slow">
              &ldquo;{verseOfDay.verse}&rdquo;
            </p>
            
            <div className="flex items-center justify-center gap-4">
              <span className="text-[#D4AF37] ui-text">{verseOfDay.reference}</span>
              <span className="text-[#F5F5F0]/40">•</span>
              <span className="text-[#F5F5F0]/60 text-sm">{verseOfDay.chapter}</span>
            </div>
          </div>

          <p className="text-[#F5F5F0]/50 mt-8 text-sm">
            Return daily for new spiritual wisdom from the Bhagavad Gita
          </p>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 border-t border-[#D4AF37]/20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid md:grid-cols-4 gap-8 mb-12">
            {/* Brand */}
            <div className="md:col-span-2">
              <div className="flex items-center gap-2 mb-4">
                <Sparkles className="w-6 h-6 text-[#D4AF37]" />
                <span className="text-xl font-bold text-[#D4AF37]" style={{ fontFamily: 'Cinzel Decorative, serif' }}>
                  Gita Wisdom
                </span>
              </div>
              <p className="text-[#F5F5F0]/60 max-w-md">
                Discover the timeless wisdom of the Bhagavad Gita. 
                A guide to self-realization, inner peace, and spiritual enlightenment.
              </p>
            </div>

            {/* Quick Links */}
            <div>
              <h4 className="text-[#F5F5F0] font-bold mb-4 ui-text">Quick Links</h4>
              <ul className="space-y-2">
                {['Home', 'About', 'Chapters', 'Teachings'].map((link) => (
                  <li key={link}>
                    <button
                      onClick={() => scrollToSection(link.toLowerCase())}
                      className="text-[#F5F5F0]/60 hover:text-[#D4AF37] transition-colors ui-text"
                    >
                      {link}
                    </button>
                  </li>
                ))}
              </ul>
            </div>

            {/* Connect */}
            <div>
              <h4 className="text-[#F5F5F0] font-bold mb-4 ui-text">Daily Practice</h4>
              <p className="text-[#F5F5F0]/60 text-sm mb-4">
                Read one verse daily and reflect on its meaning in your life.
              </p>
              <div className="flex items-center gap-2 text-[#D4AF37]">
                <Star className="w-4 h-4" />
                <span className="text-sm ui-text">Hari Om Tat Sat</span>
              </div>
            </div>
          </div>

          <div className="pt-8 border-t border-[#D4AF37]/10 text-center">
            <p className="text-[#F5F5F0]/40 text-sm">
              © {new Date().getFullYear()} Gita Wisdom. May the divine wisdom guide your path.
            </p>
          </div>
        </div>
      </footer>

      {/* Chapter Detail Modal */}
      {selectedChapter && (
        <div 
          className="fixed inset-0 z-[100] flex items-center justify-center p-4"
          onClick={() => setSelectedChapter(null)}
        >
          <div className="absolute inset-0 bg-[#0F0F1A]/90 backdrop-blur-sm" />
          
          <div 
            className="relative w-full max-w-4xl max-h-[90vh] overflow-auto glass rounded-3xl border border-[#D4AF37]/30"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Header */}
            <div className="sticky top-0 glass border-b border-[#D4AF37]/20 p-6 flex items-center justify-between">
              <div>
                <h2 
                  className="text-2xl font-bold text-[#F5F5F0]"
                  style={{ fontFamily: 'Cinzel Decorative, serif' }}
                >
                  Chapter {selectedChapter.id}: {selectedChapter.name}
                </h2>
                <p className="text-[#D4AF37]">{selectedChapter.sanskritName}</p>
              </div>
              <button 
                onClick={() => setSelectedChapter(null)}
                className="p-2 hover:bg-[#D4AF37]/10 rounded-full transition-colors"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            <div className="p-6 space-y-8">
              {/* Summary */}
              <div>
                <h3 className="text-lg font-bold text-[#D4AF37] mb-3 ui-text">Summary</h3>
                <p className="text-[#F5F5F0]/80 leading-relaxed">{selectedChapter.summary}</p>
              </div>

              {/* Key Teaching */}
              <div className="p-6 bg-gradient-to-r from-[#D4AF37]/10 to-transparent rounded-xl border-l-4 border-[#D4AF37]">
                <h3 className="text-lg font-bold text-[#D4AF37] mb-2 ui-text">Key Teaching</h3>
                <p className="text-[#F5F5F0] text-lg italic">&ldquo;{selectedChapter.keyTeaching}&rdquo;</p>
              </div>

              {/* Verses */}
              <div>
                <h3 className="text-lg font-bold text-[#D4AF37] mb-4 ui-text">Selected Verses</h3>
                <div className="space-y-4">
                  {selectedChapter.versesList.map((verse) => (
                    <div 
                      key={verse.id}
                      className="p-6 glass rounded-xl border border-[#D4AF37]/20 hover:border-[#D4AF37]/40 transition-colors"
                    >
                      <div className="flex items-start justify-between mb-4">
                        <span className="text-sm text-[#D4AF37]">Verse {verse.id}</span>
                        <div className="flex gap-2">
                          <button
                            onClick={() => speakVerse(verse.translation)}
                            className="p-2 hover:bg-[#D4AF37]/10 rounded-full transition-colors"
                          >
                            {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
                          </button>
                          <button
                            onClick={() => toggleBookmark(verse.id)}
                            className="p-2 hover:bg-[#D4AF37]/10 rounded-full transition-colors"
                          >
                            <Bookmark 
                              className={`w-4 h-4 ${bookmarkedVerses.includes(verse.id) ? 'fill-[#D4AF37] text-[#D4AF37]' : ''}`} 
                            />
                          </button>
                        </div>
                      </div>
                      
                      <p className="text-[#D4AF37]/80 text-sm mb-3 font-serif">{verse.sanskrit}</p>
                      <p className="text-[#F5F5F0]/60 text-sm mb-4 italic">{verse.transliteration}</p>
                      <p className="text-[#F5F5F0] mb-3">{verse.translation}</p>
                      <p className="text-[#F5F5F0]/60 text-sm">{verse.meaning}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

export default App;
