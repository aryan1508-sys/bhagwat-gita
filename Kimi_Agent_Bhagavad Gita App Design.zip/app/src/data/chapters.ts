export interface Chapter {
  id: number;
  name: string;
  sanskritName: string;
  verses: number;
  summary: string;
  keyTeaching: string;
  versesList: Verse[];
}

export interface Verse {
  id: number;
  chapterId: number;
  sanskrit: string;
  transliteration: string;
  translation: string;
  meaning: string;
}

export const chapters: Chapter[] = [
  {
    id: 1,
    name: "Arjuna's Dilemma",
    sanskritName: "अर्जुनविषादयोग",
    verses: 47,
    summary: "The chapter opens on the battlefield of Kurukshetra. Arjuna, the great warrior, is overcome with grief and moral dilemma seeing his relatives, teachers, and friends in the enemy army. He refuses to fight, overwhelmed by sorrow and confusion.",
    keyTeaching: "Emotional confusion and attachment can lead to inaction and suffering.",
    versesList: [
      {
        id: 1,
        chapterId: 1,
        sanskrit: "धृतराष्ट्र उवाच | धर्मक्षेत्रे कुरुक्षेत्रे समवेता युयुत्सवः | मामकाः पाण्डवाश्चैव किमकुर्वत सञ्जय ||1||",
        transliteration: "Dhritarashtra uvacha: Dharma-ksetre kuru-ksetre samaveta yuyutsavah | Mamakah Pandavas caiva kim akurvata Sanjaya ||1||",
        translation: "Dhritarashtra said: O Sanjaya, after my sons and the sons of Pandu assembled in the place of pilgrimage at Kurukshetra, desiring to fight, what did they do?",
        meaning: "The blind King Dhritarashtra asks his charioteer Sanjaya to narrate what happened on the battlefield. His attachment to his sons clouds his vision."
      },
      {
        id: 21,
        chapterId: 1,
        sanskrit: "अर्जुन उवाच | सेनयोरुभयोर्मध्ये रथं स्थापय मेऽच्युत | यावदेतान्निरीक्षेऽहं योद्धुकामानवस्थितान् ||21||",
        transliteration: "Arjuna uvaca: Senayor ubhayor madhye ratham sthapaya me 'chyuta | Yavad etan nirikshe 'ham yoddhu-kaman avasthitan ||21||",
        translation: "Arjuna said: O infallible one, please draw my chariot between the two armies so that I may see those present here who desire to fight.",
        meaning: "Arjuna asks Krishna to position the chariot so he can see who he must fight against."
      },
      {
        id: 47,
        chapterId: 1,
        sanskrit: "सञ्जय उवाच | एवमुक्त्वार्जुनः संख्ये रथोपस्थ उपाविशत् | विसृज्य सशरं चापं शोकसंविग्नमानसः ||47||",
        transliteration: "Sanjaya uvaca: Evam uktvarjunah sankhye rathopastha upavishat | Visrjya sa-saram capam soka-samvigna-manasah ||47||",
        translation: "Sanjaya said: Speaking thus, Arjuna cast aside his bow and arrows, and sat down on the chariot, his mind overwhelmed with grief.",
        meaning: "Arjuna is overcome with sorrow and refuses to fight, setting the stage for Krishna's divine teachings."
      }
    ]
  },
  {
    id: 2,
    name: "Sankhya Yoga",
    sanskritName: "सांख्ययोग",
    verses: 72,
    summary: "Krishna begins his teachings by explaining the eternal nature of the soul (Atman). The body is temporary, but the soul never dies. He introduces Karma Yoga - performing duty without attachment to results.",
    keyTeaching: "You have the right to perform your duty, but not the right to its fruits.",
    versesList: [
      {
        id: 11,
        chapterId: 2,
        sanskrit: "श्रीभगवानुवाच | अशोच्यानन्वशोचस्त्वं प्रज्ञावादांश्च भाषसे | गतासूनगतासूंश्च नानुशोचन्ति पण्डिताः ||11||",
        transliteration: "Sri-bhagavan uvaca: Asochyam anvasochas tvam prajna-vadams ca bhasase | Gatasun agatasums ca nanusochanti panditah ||11||",
        translation: "The Blessed Lord said: While speaking learned words, you are mourning for what is not worthy of grief. The wise lament neither for the living nor the dead.",
        meaning: "Krishna begins to teach Arjuna about the eternal nature of the soul and the futility of grieving for the physical body."
      },
      {
        id: 20,
        chapterId: 2,
        sanskrit: "न जायते म्रियते वा कदाचिन्नायं भूत्वा भविता वा न भूयः | अजो नित्यः शाश्वतोऽयं पुराणो न हन्यते हन्यमाने शरीरे ||20||",
        transliteration: "Na jayate mriyate va kadacin nayam bhutva bhavita va na bhuyah | Ajo nityah sasvato 'yam purano na hanyate hanyamane sarire ||20||",
        translation: "For the soul there is neither birth nor death at any time. He has not come into being, does not come into being, and will not come into being. He is unborn, eternal, ever-existing, and primeval. He is not slain when the body is slain.",
        meaning: "This is one of the most important verses describing the eternal, indestructible nature of the soul."
      },
      {
        id: 47,
        chapterId: 2,
        sanskrit: "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन | मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि ||47||",
        transliteration: "Karmanye vadhikaraste ma phalesu kadacana | Ma karma-phala-hetur bhur ma te sango 'stv akarmani ||47||",
        translation: "You have a right to perform your prescribed duty, but you are not entitled to the fruits of action. Never consider yourself the cause of the results of your activities, and never be attached to not doing your duty.",
        meaning: "This is the most famous verse of the Gita, teaching the principle of detached action - performing one's duty without attachment to results."
      }
    ]
  },
  {
    id: 3,
    name: "Karma Yoga",
    sanskritName: "कर्मयोग",
    verses: 43,
    summary: "Emphasizes selfless action performed without attachment to results as a path to liberation. Action is necessary for life, and one must perform their duty without selfish desires.",
    keyTeaching: "A wise person performs duty without attachment, for the welfare of the world.",
    versesList: [
      {
        id: 19,
        chapterId: 3,
        sanskrit: "तस्मादसक्तः सततं कार्यं कर्म समाचर | असक्तो ह्याचरन्कर्म परमाप्नोति पूरुषः ||19||",
        transliteration: "Tasmad asaktah satatam karyam karma samacara | Asakto hy acaran karma param apnoti purusah ||19||",
        translation: "Therefore, without attachment, perform your duty, for working without attachment, a person attains the Supreme.",
        meaning: "Krishna emphasizes the importance of performing one's duty without attachment to the results."
      },
      {
        id: 42,
        chapterId: 3,
        sanskrit: "इन्द्रियाणि पराण्याहुरिन्द्रियेभ्यः परं मनः | मनसस्तु परा बुद्धिर्यो बुद्धेः परतस्तु सः ||42||",
        transliteration: "Indriyani parany ahur indriyebhyah param manah | Manasas tu para buddhir yo buddheh paratas tu sah ||42||",
        translation: "The working senses are superior to dull matter; mind is higher than the senses; intelligence is still higher than the mind; and the soul is even higher than the intelligence.",
        meaning: "Krishna explains the hierarchy of consciousness: senses → mind → intelligence → soul."
      }
    ]
  },
  {
    id: 4,
    name: "Jnana Karma Sanyasa Yoga",
    sanskritName: "ज्ञानकर्मसंन्यासयोग",
    verses: 42,
    summary: "Discusses the relationship between knowledge and action, and the importance of renouncing the fruits of actions. Krishna reveals that He manifests in the world to protect righteousness.",
    keyTeaching: "Whenever there is a decline in righteousness, I manifest to restore dharma.",
    versesList: [
      {
        id: 7,
        chapterId: 4,
        sanskrit: "यदा यदा हि धर्मस्य ग्लानिर्भवति भारत | अभ्युत्थानमधर्मस्य तदात्मानं सृजाम्यहम् ||7||",
        transliteration: "Yada yada hi dharmasya glanir bhavati Bharata | Abhyutthanam adharmasya tadatmanam srjamy aham ||7||",
        translation: "Whenever and wherever there is a decline in religious practice, O descendant of Bharata, and a predominant rise of irreligion—at that time I descend Myself.",
        meaning: "Krishna explains His divine mission: to appear whenever righteousness declines and unrighteousness rises."
      },
      {
        id: 8,
        chapterId: 4,
        sanskrit: "परित्राणाय साधूनां विनाशाय च दुष्कृताम् | धर्मसंस्थापनार्थाय सम्भवामि युगे युगे ||8||",
        transliteration: "Paritranaya sadhunam vinasaya ca duskrtam | Dharma-samsthapanarthaya sambhavami yuge yuge ||8||",
        translation: "To deliver the pious and to annihilate the miscreants, as well as to reestablish the principles of religion, I Myself appear, millennium after millennium.",
        meaning: "Krishna reveals His purpose for incarnating: to protect the good, destroy evil, and reestablish dharma."
      }
    ]
  },
  {
    id: 5,
    name: "Karma Sanyasa Yoga",
    sanskritName: "कर्मसंन्यासयोग",
    verses: 29,
    summary: "Explores the concept of renunciation and the qualities of a true renunciate. Both Karma Yoga and Jnana Yoga lead to liberation. The best path is detached action with devotion.",
    keyTeaching: "A person who acts without attachment and dedicates work to God is free.",
    versesList: [
      {
        id: 10,
        chapterId: 5,
        sanskrit: "ब्रह्मण्याधाय कर्माणि सङ्गं त्यक्त्वा करोति यः | लिप्यते न स पापेन पद्मपत्रमिवाम्भसा ||10||",
        transliteration: "Brahmany adhaya karmani sangam tyaktva karoti yah | Lipyate na sa papena padma-patram ivambhasa ||10||",
        translation: "One who performs his duty without attachment, surrendering the results unto the Supreme Lord, is unaffected by sinful action, as the lotus leaf is untouched by water.",
        meaning: "Krishna uses the beautiful analogy of a lotus leaf remaining dry despite being in water to describe how one can act without being tainted by the results."
      }
    ]
  },
  {
    id: 6,
    name: "Dhyana Yoga",
    sanskritName: "आत्मसंयमयोग",
    verses: 47,
    summary: "Highlights the significance of meditation as a means to control the mind and attain self-realization. A true yogi is one who sees all beings as equal.",
    keyTeaching: "The best yogi is the one who worships Me with love and devotion.",
    versesList: [
      {
        id: 5,
        chapterId: 6,
        sanskrit: "उद्धरेदात्मनात्मानं नात्मानमवसादयेत् | आत्मैव ह्यात्मनो बन्धुरात्मैव रिपुरात्मनः ||5||",
        transliteration: "Uddhared atmanatmanam natmanam avasadayet | Atmaiva hy atmano bandhur atmaiva ripur atmanah ||5||",
        translation: "One must deliver himself with the help of his mind, and not degrade himself. The mind is the friend of the conditioned soul, and his enemy as well.",
        meaning: "Krishna teaches that the mind can be either our greatest friend or our worst enemy - it depends on how we control and use it."
      },
      {
        id: 47,
        chapterId: 6,
        sanskrit: "योगिनामपि सर्वेषां मद्गतेनान्तरात्मना | श्रद्धावान्भजते यो मां स मे युक्ततमो मतः ||47||",
        transliteration: "Yoginam api sarvesam mad-gatenantar-atmana | Sraddhavan bhajate yo mam sa me yuktatamo matah ||47||",
        translation: "And of all yogis, the one with great faith who always abides in Me, thinks of Me within himself, and renders transcendental loving service to Me—he is the most intimately united with Me in yoga and is the highest of all.",
        meaning: "Krishna declares that the highest yogi is the one who worships Him with faith and devotion."
      }
    ]
  },
  {
    id: 7,
    name: "Jnana Vijnana Yoga",
    sanskritName: "ज्ञानविज्ञानयोग",
    verses: 30,
    summary: "Differentiates between theoretical knowledge and experiential wisdom, emphasizing understanding of the divine. Krishna reveals Himself as the ultimate truth and the cause of creation.",
    keyTeaching: "Among thousands, only a rare soul truly knows Me.",
    versesList: [
      {
        id: 3,
        chapterId: 7,
        sanskrit: "यो मामजमनादिं च वेत्ति लोकमहेश्वरम् | असम्मूढः स मर्त्येषु सर्वपापैः प्रमुच्यते ||3||",
        transliteration: "Yo mam ajam anadim ca vetti loka-mahesvaram | Asammudhah sa martyesu sarva-papaih pramucyate ||3||",
        translation: "One who knows Me as unborn and beginningless, as the Supreme Lord of all the worlds—he, among mortals, is undeluded and liberated from all sins.",
        meaning: "True knowledge of Krishna's divine nature leads to liberation from all sins."
      }
    ]
  },
  {
    id: 8,
    name: "Akshara Brahma Yoga",
    sanskritName: "अक्षरब्रह्मयोग",
    verses: 28,
    summary: "Discusses the eternal nature of Brahman and the process of realizing it. Those who remember Krishna at the time of death attain eternal peace.",
    keyTeaching: "Whoever remembers Me at the time of death reaches My eternal abode.",
    versesList: [
      {
        id: 5,
        chapterId: 8,
        sanskrit: "अन्तकाले च मामेव स्मरन्मुक्त्वा कलेवरम् | यः प्रयाति स मद्भावं याति नास्त्यत्र संशयः ||5||",
        transliteration: "Anta-kale ca mam eva smaran muktva kalevaram | Yah prayati sa mad-bhavam yati nasty atra samsayah ||5||",
        translation: "And whoever, at the end of his life, quits his body remembering Me alone at once attains My nature. Of this there is no doubt.",
        meaning: "Krishna assures that whoever remembers Him at the time of death attains His divine nature."
      },
      {
        id: 6,
        chapterId: 8,
        sanskrit: "यं यं वापि स्मरन्भावं त्यजत्यन्ते कलेवरम् | तं तमेवैति कौन्तेय सदा तद्भावभावितः ||6||",
        transliteration: "Yam yam vapi smaran bhavam tyajaty ante kalevaram | Tam tam evaiti Kaunteya sada tad-bhava-bhavitah ||6||",
        translation: "Whatever state of being one remembers when he quits his body, O son of Kunti, that state he will attain without fail.",
        meaning: "Our final destination is determined by what we think of at the time of death - hence the importance of always remembering God."
      }
    ]
  },
  {
    id: 9,
    name: "Raja Vidya Raja Guhya Yoga",
    sanskritName: "राजविद्याराजगुह्ययोग",
    verses: 34,
    summary: "Reveals the most confidential knowledge about the supreme truth and the path to attain it. Krishna declares Bhakti (devotion) as the highest path.",
    keyTeaching: "Whoever worships Me with love, I protect them and fulfill their needs.",
    versesList: [
      {
        id: 22,
        chapterId: 9,
        sanskrit: "अनन्याश्चिन्तयन्तो मां ये जनाः पर्युपासते | तेषां नित्याभियुक्तानां योगक्षेमं वहाम्यहम् ||22||",
        transliteration: "Ananya-cintayanto mam ye janah paryupasate | Tesam nityabhiyuktanam yoga-ksemam vahamy aham ||22||",
        translation: "But those who always worship Me with exclusive devotion, meditating on My transcendental form—to them I carry what they lack, and I preserve what they have.",
        meaning: "Krishna promises to protect and provide for those who worship Him with exclusive devotion."
      }
    ]
  },
  {
    id: 10,
    name: "Vibhuti Yoga",
    sanskritName: "विभूतियोग",
    verses: 42,
    summary: "Krishna describes His divine manifestations present throughout the universe. He is present in all greatness, power, and beauty.",
    keyTeaching: "I am the source of all creation. Everything moves because of Me.",
    versesList: [
      {
        id: 8,
        chapterId: 10,
        sanskrit: "अहं सर्वस्य प्रभवो मत्तः सर्वं प्रवर्तते | इति मत्वा भजन्ते मां बुधा भावसमन्विताः ||8||",
        transliteration: "Aham sarvasya prabhavo mattah sarvam pravartate | Iti matva bhajante mam budha bhava-samanvitah ||8||",
        translation: "I am the source of all spiritual and material worlds. Everything emanates from Me. The wise who perfectly know this engage in My devotional service.",
        meaning: "Krishna declares Himself as the source of everything, and those who know this worship Him with devotion."
      },
      {
        id: 20,
        chapterId: 10,
        sanskrit: "अहमात्मा गुडाकेश सर्वभूताशयस्थितः | अहमादिश्च मध्यं च भूतानामन्त एव च ||20||",
        transliteration: "Aham atma Gudakesa sarva-bhutasaya-sthitah | Aham adis ca madhyam ca bhutanam anta eva ca ||20||",
        translation: "I am the Self, O Gudakesa, seated in the hearts of all creatures. I am the beginning, the middle, and the end of all beings.",
        meaning: "Krishna reveals that He is the Supersoul present in everyone's heart, and He is the beginning, middle, and end of all existence."
      }
    ]
  },
  {
    id: 11,
    name: "Vishvarupa Darshana Yoga",
    sanskritName: "विश्वरूपदर्शनयोग",
    verses: 55,
    summary: "Arjuna is granted the vision of Krishna's universal form, showcasing His omnipresence. Krishna reveals His Cosmic Form—a vision of infinite power, time, and destruction.",
    keyTeaching: "Time, I am, the destroyer of worlds.",
    versesList: [
      {
        id: 32,
        chapterId: 11,
        sanskrit: "श्रीभगवानुवाच | कालोऽस्मि लोकक्षयकृत्प्रवृद्धो लोकान्समाहर्तुमिह प्रवृत्तः | ऋतेऽपि त्वां न भविष्यन्ति सर्वे येऽवस्थिताः प्रत्यनीकेषु योधाः ||32||",
        transliteration: "Sri-bhagavan uvaca: Kalo 'smi loka-ksaya-krt pravrddho lokan samahartum iha pravrttah | Rte 'pi tvam na bhavisyanti sarve ye 'vasthitah prati-anikesu yodhah ||32||",
        translation: "The Supreme Personality of Godhead said: Time I am, the great destroyer of the worlds, and I have come here to destroy all people. With the exception of you [the Pandavas], all the soldiers here on both sides will be slain.",
        meaning: "Krishna reveals His terrifying aspect as all-devouring time, which destroys everything in due course."
      }
    ]
  },
  {
    id: 12,
    name: "Bhakti Yoga",
    sanskritName: "भक्तियोग",
    verses: 20,
    summary: "Krishna declares Bhakti (devotion) as the simplest and highest path to liberation. A true devotee is humble, patient, and loving.",
    keyTeaching: "Whoever worships Me with love and faith, I reside in their heart.",
    versesList: [
      {
        id: 6,
        chapterId: 12,
        sanskrit: "ये तु सर्वाणि कर्माणि मयि संन्यस्य मत्परः | अनन्येनैव योगेन मां ध्यायन्त उपासते ||6||",
        transliteration: "Ye tu sarvani karmani mayi sannyasya mat-parah | Ananyenaiva yogena mam dhyayanta upasate ||6||",
        translation: "But those who worship Me, giving up all their activities unto Me and being devoted to Me without deviation, engaged in devotional service and always meditating upon Me.",
        meaning: "Krishna describes the qualities of His pure devotees who worship Him with exclusive devotion."
      },
      {
        id: 7,
        chapterId: 12,
        sanskrit: "तेषामहं समुद्धर्ता मृत्युसंसारसागरात् | भवामि नचिरात्पार्थ मय्यावेशितचेतसाम् ||7||",
        transliteration: "Tesam aham samuddharta mrtyu-samsara-sagarat | Bhavami na cirat Partha mayy avesita-cetasam ||7||",
        translation: "O son of Prtha, for those whose minds are absorbed in Me, I am the swift deliverer from the ocean of birth and death.",
        meaning: "Krishna promises to quickly deliver His devotees from the cycle of birth and death."
      }
    ]
  },
  {
    id: 13,
    name: "Kshetra Kshetragna Vibhaga Yoga",
    sanskritName: "क्षेत्रक्षेत्रज्ञविभागयोग",
    verses: 35,
    summary: "Explores the distinction between the physical body (field) and the soul (knower of the field). Krishna explains the difference between the material world and the eternal soul.",
    keyTeaching: "The soul is beyond birth and death.",
    versesList: [
      {
        id: 1,
        chapterId: 13,
        sanskrit: "अर्जुन उवाच | प्रकृतिं पुरुषं चैव क्षेत्रं क्षेत्रज्ञमेव च | एतद्वेदितुमिच्छामि ज्ञानं ज्ञेयं च केशव ||1||",
        transliteration: "Arjuna uvaca: Prakrtim purusam caiva ksetram ksetra-jnam eva ca | Etad veditum icchami jnanam jneyam ca Kesava ||1||",
        translation: "Arjuna said: O my dear Krishna, I wish to know about prakriti [nature], purusa [the enjoyer], and the field and the knower of the field, and of knowledge and the object of knowledge.",
        meaning: "Arjuna asks Krishna to explain the difference between the body (field), the soul (knower), and the Supreme Soul."
      }
    ]
  },
  {
    id: 14,
    name: "Gunatraya Vibhaga Yoga",
    sanskritName: "गुणत्रयविभागयोग",
    verses: 27,
    summary: "Analyzes the three fundamental qualities (gunas) of nature—sattva, rajas, and tamas—and their influence on beings.",
    keyTeaching: "One who transcends the Gunas attains liberation.",
    versesList: [
      {
        id: 5,
        chapterId: 14,
        sanskrit: "सत्त्वं रजस्तम इति गुणाः प्रकृतिसम्भवाः | निबध्नन्ति महाबाहो देहे देहिनमव्ययम् ||5||",
        transliteration: "Sattvam rajas tama iti gunah prakrti-sambhavah | Nibadhnanti maha-baho dehe dehinam avyayam ||5||",
        translation: "Material nature consists of three modes—goodness, passion and ignorance. When the eternal living entity comes in contact with nature, O mighty-armed Arjuna, he becomes conditioned by these modes.",
        meaning: "Krishna introduces the three modes of material nature that bind the soul."
      },
      {
        id: 6,
        chapterId: 14,
        sanskrit: "तत्र सत्त्वं निर्मलत्वात्प्रकाशकमनामयम् | सुखसङ्गेन बध्नाति ज्ञानसङ्गेन चानघ ||6||",
        transliteration: "Tatra sattvam nirmalatvat prakasakam anamayam | Sukha-sangena badhnati jnana-sangena canagha ||6||",
        translation: "O sinless one, the mode of goodness, being purer than the others, is illuminating, and it frees one from all sinful reactions. Those situated in that mode become conditioned by a sense of happiness and knowledge.",
        meaning: "Sattva (goodness) is characterized by purity, knowledge, and happiness."
      }
    ]
  },
  {
    id: 15,
    name: "Purushottama Yoga",
    sanskritName: "पुरुषोत्तमयोग",
    verses: 20,
    summary: "Describes the supreme person (Purushottama) and the means to realize Him. The world is like an inverted tree, where detachment leads to true wisdom.",
    keyTeaching: "Those who know Me as the Supreme Purusha attain liberation.",
    versesList: [
      {
        id: 1,
        chapterId: 15,
        sanskrit: "श्रीभगवानुवाच | ऊर्ध्वमूलमधःशाखमश्वत्थं प्राहुरव्ययम् | छन्दांसि यस्य पर्णानि यस्तं वेद स वेदवित् ||1||",
        transliteration: "Sri-bhagavan uvaca: Urdhva-mulam adhah-sakham asvattham prahur avyayam | Chandamsi yasya parnani yas tam veda sa veda-vit ||1||",
        translation: "The Supreme Personality of Godhead said: It is said that there is an imperishable banyan tree that has its roots upward and its branches down and whose leaves are the Vedic hymns. One who knows this tree is the knower of the Vedas.",
        meaning: "Krishna uses the analogy of an upside-down tree to describe the material world, with its roots in the spiritual sky."
      }
    ]
  },
  {
    id: 16,
    name: "Daivasura Sampad Vibhaga Yoga",
    sanskritName: "दैवासुरसम्पद्विभागयोग",
    verses: 24,
    summary: "Contrasts the qualities of the divine and demonic natures in individuals. Humility, truth, and devotion lead to salvation.",
    keyTeaching: "A divine person follows righteousness, while an evil person follows desires.",
    versesList: [
      {
        id: 1,
        chapterId: 16,
        sanskrit: "श्रीभगवानुवाच | अभयं सत्त्वसंशुद्धिर्ज्ञानयोगव्यवस्थितिः | दानं दमश्च यज्ञश्च स्वाध्यायस्तप आर्जवम् ||1||",
        transliteration: "Sri-bhagavan uvaca: Abhayam sattva-samsuddhir jnana-yoga-vyavasthitih | Danam damas ca yajnas ca svadhyayas tapa arjavam ||1||",
        translation: "The Supreme Personality of Godhead said: Fearlessness; purification of one's existence; cultivation of spiritual knowledge; charity; self-control; performance of sacrifice; study of the Vedas; austerity; simplicity.",
        meaning: "Krishna begins describing the divine qualities that lead to liberation."
      },
      {
        id: 4,
        chapterId: 16,
        sanskrit: "दम्भो दर्पोऽभिमानश्च क्रोधः पारुष्यमेव च | अज्ञानं चाभिजातस्य पार्थ सम्पदमासुरीम् ||4||",
        transliteration: "Dambho darpo 'bhimanas ca krodhah parusyam eva ca | Ajnanam cabhijatasya Partha sampadam asurim ||4||",
        translation: "Pride, arrogance, conceit, anger, harshness and ignorance—these qualities belong to those of demoniac nature, O son of Prtha.",
        meaning: "Krishna describes the demoniac qualities that bind one to material existence."
      }
    ]
  },
  {
    id: 17,
    name: "Sraddhatraya Vibhaga Yoga",
    sanskritName: "श्रद्धात्रयविभागयोग",
    verses: 28,
    summary: "Discusses the three types of faith corresponding to the three gunas and their implications. True devotion should be selfless and pure.",
    keyTeaching: "Faith determines one's destiny.",
    versesList: [
      {
        id: 3,
        chapterId: 17,
        sanskrit: "सत्त्वानुरूपा सर्वस्य श्रद्धा भवति भारत | श्रद्धामयोऽयं पुरुषो यो यच्छ्रद्धः स एव सः ||3||",
        transliteration: "Sattvanurupa sarvasya sraddha bhavati Bharata | Sraddha-mayo 'yam puruso yo yac-chraddhah sa eva sah ||3||",
        translation: "O son of Bharata, according to one's existence under the various modes of nature, one evolves a particular kind of faith. The living being is said to be of a particular faith according to the modes he has acquired.",
        meaning: "Our faith and beliefs are shaped by the mode of nature (guna) that predominates in us."
      }
    ]
  },
  {
    id: 18,
    name: "Moksha Sanyasa Yoga",
    sanskritName: "मोक्षसंन्यासयोग",
    verses: 78,
    summary: "Concludes the teachings by summarizing the paths of knowledge, action, and devotion leading to liberation. Krishna urges Arjuna to surrender to Him completely.",
    keyTeaching: "Abandon all duties and surrender to Me; I will free you from all sins.",
    versesList: [
      {
        id: 66,
        chapterId: 18,
        sanskrit: "सर्वधर्मान्परित्यज्य मामेकं शरणं व्रज | अहं त्वां सर्वपापेभ्यो मोक्षयिष्यामि मा शुचः ||66||",
        transliteration: "Sarva-dharman parityajya mam ekam saranam vraja | Aham tvam sarva-papebhyo moksyami ma sucah ||66||",
        translation: "Abandon all varieties of religion and just surrender unto Me. I shall deliver you from all sinful reactions. Do not fear.",
        meaning: "This is the essence of the entire Gita - complete surrender to Krishna leads to liberation from all sins."
      },
      {
        id: 78,
        chapterId: 18,
        sanskrit: "यत्र योगेश्वरः कृष्णो यत्र पार्धो धनुर्धरः | तत्र श्रीर्विजयो भूतिर्ध्रुवा नीतिर्मतिर्मम ||78||",
        transliteration: "Yatra yogesvarah Krishno yatra Partho dhanur-dharah | Tatra srir vijayo bhutir dhruva nitir matir mama ||78||",
        translation: "Wherever there is Krishna, the master of all mystics, and wherever there is Arjuna, the supreme archer, there will also certainly be opulence, victory, extraordinary power, and morality. That is my opinion.",
        meaning: "Sanjaya concludes by declaring that where Krishna and Arjuna are present, there is always victory and prosperity."
      }
    ]
  }
];

export const dailyVerses = [
  {
    verse: "You have the right to perform your prescribed duties, but you are not entitled to the fruits of your actions.",
    reference: "Bhagavad Gita 2.47",
    chapter: "Sankhya Yoga"
  },
  {
    verse: "For the soul there is neither birth nor death at any time. He is unborn, eternal, ever-existing, and primeval.",
    reference: "Bhagavad Gita 2.20",
    chapter: "Sankhya Yoga"
  },
  {
    verse: "Whenever there is a decline in righteousness, I manifest Myself to restore dharma.",
    reference: "Bhagavad Gita 4.7",
    chapter: "Jnana Karma Sanyasa Yoga"
  },
  {
    verse: "Whoever remembers Me at the time of death reaches My eternal abode.",
    reference: "Bhagavad Gita 8.5",
    chapter: "Akshara Brahma Yoga"
  },
  {
    verse: "Abandon all varieties of religion and just surrender unto Me. I shall deliver you from all sinful reactions.",
    reference: "Bhagavad Gita 18.66",
    chapter: "Moksha Sanyasa Yoga"
  },
  {
    verse: "The mind is the friend of the conditioned soul, and his enemy as well.",
    reference: "Bhagavad Gita 6.5",
    chapter: "Dhyana Yoga"
  },
  {
    verse: "A person who acts without attachment and dedicates work to God is free.",
    reference: "Bhagavad Gita 5.10",
    chapter: "Karma Sanyasa Yoga"
  }
];

export const getDailyVerse = () => {
  const dayOfWeek = new Date().getDay();
  return dailyVerses[dayOfWeek];
};
